package idh.java;

public class Konto {

}
